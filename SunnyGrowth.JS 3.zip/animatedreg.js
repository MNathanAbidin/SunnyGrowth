//JQuery
// Scroll animation for form section
$(window).on("scroll", function () {
  // Mengambil elemen formSection berdasarkan id
  const formSection = $("#formSection");
  // Menghitung posisi form dari bagian atas viewport
  const formPosition = formSection.offset().top - $(window).scrollTop();
  // Menentukan kapan animasi dimulai (setengah tinggi layar)
  const screenPosition = $(window).height() / 1.5;

  // Jika posisi form lebih tinggi dari screenPosition, tampilkan animasi
  if (formPosition < screenPosition) {
    // Menghapus class 'hidden' dan menambahkan class 'visible' agar form muncul dengan animasi
    formSection.removeClass("hidden").addClass("visible");
  }
});

// Click animation for register button
// Mendapatkan elemen registerButton berdasarkan id
const registerButton = $("#registerButton");

// Event Listener untuk menambahkan animasi shake saat tombol "register" diklik
registerButton.on("click", function () {
  // Menambahkan animasi shake
  registerButton.addClass("shake");

  // Menghapus animasi shake setelah 500ms
  setTimeout(function () {
    registerButton.removeClass("shake");
  }, 500);
});

/*
// Javascript Vanilla
// Scroll animation for form section
    // Event Listener untuk mendeteksi ketika pengguna melakukan scroll pada halaman
    window.addEventListener('scroll', function() {
      // Mengambil elemen formSection berdasarkan id
      const formSection = document.getElementById('formSection');
      // Menghitung posisi form dari bagian atas viewport
      const formPosition = formSection.getBoundingClientRect().top;
      // Menentukan kapan animasi dimulai (setengah tinggi layar)
      const screenPosition = window.innerHeight / 1.5;

      // Jika posisi form lebih tinggi dari screenPosition, tampilkan animasi
      if (formPosition < screenPosition) {
          // Menghapus class 'hidden' dan menambahkan class 'visible' agar form muncul dengan animasi
          formSection.classList.remove('hidden');
          formSection.classList.add('visible');
      }
  });

  // Click animation for register button
  // Mendapatkan elemen registerButton berdasarkan id
  const registerButton = document.getElementById('registerButton');
  // Event Listener untuk menambahkan animasi shake saat tombol "register" diklik
  registerButton.addEventListener('click', function() {
      // Menambahkan animasi shake
      registerButton.classList.add('shake');
      // Menghapus animasi shake setelah 500ms
      setTimeout(() => {
          registerButton.classList.remove('shake');
      }, 500);
  });
*/
