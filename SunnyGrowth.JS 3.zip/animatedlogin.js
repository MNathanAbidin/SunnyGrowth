//Jquery
// Event Listener untuk mendeteksi scroll pada halaman
$(window).on("scroll", function () {
  // Mengambil elemen form login dan gambar login berdasarkan id
  var form = $("#form-login");
  var image = $("#login-image");

  // Menghitung posisi elemen form dan gambar dari bagian atas viewport
  var formPosition = form.offset().top - $(window).scrollTop();
  var imagePosition = image.offset().top - $(window).scrollTop();

  // Menentukan posisi layar ketika animasi dimulai (setengah tinggi layar)
  var screenPosition = $(window).height() / 1.5;

  // Jika posisi form lebih tinggi dari screenPosition, tambahkan animasi fadeInLeft
  if (formPosition < screenPosition) {
    form.addClass("animate__animated animate__fadeInLeft");
  }

  // Jika posisi gambar lebih tinggi dari screenPosition, tambahkan animasi fadeInRight
  if (imagePosition < screenPosition) {
    image.addClass("animate__animated animate__fadeInRight");
  }
});

/*
//Javascript Vanilla
// Event Listener untuk mendeteksi scroll pada halaman
window.addEventListener("scroll", function () {
  // Mengambil elemen form login dan gambar login berdasarkan id
  var form = document.getElementById("form-login");
  var image = document.getElementById("login-image");

  // Menghitung posisi elemen form dan gambar dari bagian atas viewport
  var formPosition = form.getBoundingClientRect().top;
  var imagePosition = image.getBoundingClientRect().top;

  // Menentukan posisi layar ketika animasi dimulai (setengah tinggi layar)
  var screenPosition = window.innerHeight / 1.5;

  // Jika posisi form lebih tinggi dari screenPosition, tambahkan animasi fadeInLeft
  if (formPosition < screenPosition) {
    form.classList.add("animate__animated", "animate__fadeInLeft");
  }

  // Jika posisi gambar lebih tinggi dari screenPosition, tambahkan animasi fadeInRight
  if (imagePosition < screenPosition) {
    image.classList.add("animate__animated", "animate__fadeInRight");
  }
});
*/
