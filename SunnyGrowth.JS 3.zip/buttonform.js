///Jquery
// Ketika user klik button pada form maka akan muncul alert
$("[type='submit']").on("click", function (event) {
  // Stop default behavior (menghindari form langsung submit)
  event.preventDefault();

  // Melakukan pengecekan ulang pada setiap input field
  var form = $("form");
  var inputs = $(".form-control");
  var allFilled = true;

  // Perulangan untuk mengecek input dari field
  inputs.each(function () {
    if ($(this).val() === "") {
      allFilled = false;
    }
  });

  // Tampilkan alert satu kali jika ada field yang kosong
  if (!allFilled) {
    alert("Harap isi semua kolom yang tersedia!");
  } else {
    // Jika semua field terisi, lanjutkan login
    alert("Anda telah berhasil login!");
    form.submit(); // Kirim form setelah pengecekan sukses
  }
});

/*
//Javascript Vanilla
/// Ketika user klik button pada form maka akan muncul alert
const submitButton = document.querySelector("[type='submit']");
submitButton.addEventListener("click", function (event) {
  // Stop default behavior (menghindari form langsung submit)
  event.preventDefault();

  // Melakukan pengecekan ulang pada setiap input field
  const form = document.querySelector("form");
  const inputs = document.querySelectorAll(".form-control");
  let allFilled = true;

  inputs.forEach((input) => {
    //perulangan untuk mengecek input dari field
    if (input.value === "") {
      allFilled = false;
    }
  });

  // Tampilkan alert satu kali jika ada field yang kosong
  if (!allFilled) {
    alert("Harap isi semua kolom yang tersedia!");
  } else {
    // Jika semua field terisi, lanjutkan login
    alert("Anda telah berhasil login!");
    form.submit(); // Kirim form setelah pengecekan sukses
  }
});
*/
