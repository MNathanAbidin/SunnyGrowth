document.addEventListener("DOMContentLoaded", function () {
  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach((item) => {
    const question = item.querySelector(".faq-question");
    const answer = item.querySelector(".faq-answer");

    //untuk menampilkan jawaban faqs
    question.addEventListener("click", () => {
      const isActive = question.classList.contains("active");

      // menutup jawaban ketikan klik pertanyaan lain
      faqItems.forEach((otherItem) => {
        if (otherItem !== item) {
          otherItem.querySelector(".faq-question").classList.remove("active");
          otherItem.querySelector(".faq-answer").classList.remove("active");
        }
      });

      // Toggle (beralih)
      question.classList.toggle("active", !isActive);
      answer.classList.toggle("active", !isActive);
    });
  });
});
