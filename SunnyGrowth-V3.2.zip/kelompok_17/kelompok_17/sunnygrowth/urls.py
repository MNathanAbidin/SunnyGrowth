from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing, name='landing'),                               # Halaman utama
    path('about/', views.about, name='about'),                             # Halaman about
    path('features/', views.features, name='features'),                    # Halaman features
    path('faqs/', views.faqs, name='faqs'),                                # Halaman FAQs
    path('courses/', views.courses, name='courses'),                       # Halaman courses
    path('subpage/', views.subpage, name='subpage'),                       # Halaman subpage Angka
    path('subpageAT/', views.subpageAT, name='subpageAT'),                 # Halaman subpage Anggota Tubuh
    path('subpagehewan/', views.subpagehewan, name='subpagehewan'),        # Halaman subpage hewan
    path('subpagehuruf/', views.subpagehuruf, name='subpagehuruf'),        # Halaman subpage huruf
    path('subpagewarna/', views.subpagewarna, name='subpagewarna'),        # Halaman subpage warna
    path('materi1/', views.materi1, name='materi1'),                       # Halaman materi 1 yang ada didalam subpage Angka 
    path('materiAT1/', views.materiAT1, name='materiAT1'),                 # Halaman materi 1 yang ada didalam subpage anggota tubuh
    path('materihewan1/', views.materihewan1, name='materihewan1'),        # Halaman materi 1 yang ada didalam subpage hewan
    path('materihuruf1/', views.materihuruf1, name='materihuruf1'),        # Halaman materi 1 yang ada didalam subpage huruf
    path('materiwarna1/', views.materiwarna1, name='materiwarna1'),        # Halaman materi 1 yang ada didalam subpage warna
    path('login/', views.login, name='login'),                             # Halaman login
    path('register/', views.register, name='register'),                    # Halaman register
]
