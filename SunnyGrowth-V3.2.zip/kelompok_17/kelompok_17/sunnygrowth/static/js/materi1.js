const videoPlayer = document.getElementById('video-player');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

// Navigasi video - logika tambahan jika diperlukan
prevBtn.addEventListener('click', () => {
    videoPlayer.currentTime -= 10; // Mundur 10 detik
});

nextBtn.addEventListener('click', () => {
    videoPlayer.currentTime += 10; // Maju 10 detik
});
