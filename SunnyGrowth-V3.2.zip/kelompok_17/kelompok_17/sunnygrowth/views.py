from django.shortcuts import render

# Create your views here.
def landing(request):
    return render(request, 'sunnygrowth/landing.html')

def about(request):
    return render(request, 'sunnygrowth/about.html') 

def features(request):
    return render(request, 'sunnygrowth/features.html') 

def faqs(request):
    return render(request, 'sunnygrowth/faqs.html')

def courses(request):
    return render(request, 'sunnygrowth/courses.html')

def subpage(request):
    return render(request, 'sunnygrowth/subpage.html')

def subpageAT(request):
    return render(request, 'sunnygrowth/subpageAT.html')

def subpagehewan(request):
    return render(request, 'sunnygrowth/subpagehewan.html')

def subpagehuruf(request):
    return render(request, 'sunnygrowth/subpagehuruf.html')

def subpagewarna(request):
    return render(request, 'sunnygrowth/subpagewarna.html')

def materi1(request):
    return render(request, 'sunnygrowth/materi1.html')

def materiAT1(request):
    return render(request, 'sunnygrowth/materiAT1.html')

def materihewan1(request):
    return render(request, 'sunnygrowth/materihewan1.html')

def materihuruf1(request):
    return render(request, 'sunnygrowth/materihuruf1.html')

def materiwarna1(request):
    return render(request, 'sunnygrowth/materiwarna1.html')

def login(request):
    return render(request, 'sunnygrowth/login.html')

def register(request):
    return render(request, 'sunnygrowth/register.html')



